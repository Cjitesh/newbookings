<!Doctype html>
<html>
<head>
<title>DOSTI EASTERN BAY, WADALA - BY DOSTI REALTY</title>
<link rel="stylesheet" type="text/css" href="assets/css/style.css" />
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-808076997"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-808076997'); </script>
<!-- Event snippet for CSR- NB- Dosti Eastern Bay conversion page --> <script> gtag('event', 'conversion', {'send_to': 'AW-808076997/UHpeCOXEocgZEMWNqYED'}); </script>
</head>
<body>
<div style="margin-top:80px">
<center>
<br>
<h1 style="color:#053f64;font-size:50px">Thank you!</h1>
<h3  style="color:#053f64;font-size:30px">Thank you for enquiring in our project DOSTI EASTERN BAY, WADALA - BY DOSTI REALTY<br> Soon you will recieve a call back from our Team.</h3>

<br>
<script type="text/javascript">
	 window.setTimeout(function(){

        // Move to a new location or you can do something else
        window.location.href = 'index.html';

    }, 5000);
</script>
</center>
</div>


</body>
<html>